﻿//==================================================================== 
//**   基于Chromium内核及CEF框架的WEB引擎中间件（WenQue.WebEngine）
//**   脉脉含情充满精神的高尚的小强精神 - cockroach888@outlook.com
//=========================================================================
//**   Copyright © 蟑螂·魂 $year$ -- Support 文雀（风幽思静繁花落，夜半楼台听江雨。）
//=========================================================================
// 文件名称：$safeitemname$.cs
// 项目名称：华夏银河空间WEB引擎中间件
// 创建时间：$time$
// 创建人员：宋杰军
// 负责人员：宋杰军
// 参与人员：宋杰军
// ========================================================================
// 修改日期：
// 修改人员：
// 修改内容：
// ========================================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    /// <summary>
    /// 类文件功能说明。
    /// </summary>
    public sealed class $safeitemname$
    {
        /// <summary>
        /// 类文件功能说明。
        /// </summary>
        public $safeitemname$()
        {
            //do something.
        }
        
        #region 成员变量

        

        #endregion
        
        #region 成员属性

        

        #endregion

        #region 成员方法

        

        #endregion

    }
}
